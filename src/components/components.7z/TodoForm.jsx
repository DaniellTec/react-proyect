import React, {useState} from 'react';
import { v4 as uuidv4 } from "uuid";
import "bootstrap/dist/css/bootstrap.min.css";
import { BsPlusLg } from "react-icons/bs";

function TodoForm({ addTodo }){
      //Se selecciona el valor y la variable
    const [ todo, setTodo ] = useState( {

        id: "", //Id del todo
        task: "", //Nombre del elemento
        completed: false //Estado

    });

      function handleTaskChange(e){

      setTodo( {...todo, task: e.target.value }); //Se registra el valor del estado

      }    

      function handleSubmit(e){

            e.preventDefault();
            //Devuelve una cadena de texto
            if (todo.task.trim()){

                  addTodo({ ...todo, id: uuidv4() });
                  //Por cada elemento, asigna una id
                  setTodo({ ...todo, task: "" });
            }

      }

    return(

        <form onSubmit = {handleSubmit}>

        <input

            name = "task"
            type = "text"
            value = { todo.task }   
            onChange={handleTaskChange}
            
        />

        <button className="btn btn-primary"><BsPlusLg/></button>

        </form>

    )

}
export default TodoForm;