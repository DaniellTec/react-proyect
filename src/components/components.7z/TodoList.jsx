import React from 'react'
import Todo from './Todo'

//Se renderiza el componente por cada cambio de estado, useState es un array
//Rfc crea la estructura
  function TodoList( {todos} ) {

    return (
        
      <ul>

        { todos.map(todo => (

          <Todo todo={todo}/>

        ))}

      </ul>

    );
}

export default TodoList;