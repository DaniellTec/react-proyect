import React, {useState} from 'react';
import TodoList from './TodoList';
import TodoForm from './TodoForm';
import Todo from './Todo';
//import style from './style.css';

function Todos(){
          //Se selecciona el valor y la variable
    const[todos, setTodos] = useState([]);

    function addTodo(todo){

        //Selecciona todo los elementos
        setTodos([ todo, ...todos ]);

    }

    return (
        <div>

        <header>

            <p className="text">React Todo</p>
            
            {/*
            
                Se añade el componente
            
            */}

            <TodoForm addTodo = {addTodo}/>

        </header>

        </div>

    )

}

export default Todos;