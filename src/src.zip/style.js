const style = {

    input: {

        backgroundColor:'cyan',
        fontSize: '1rem',
        
    },

}