import React from 'react'
//Se importan las librerías de React
const Contacto = () => {

    return (

        <div>

            <h1> Contacto </h1>

        </div>

    )

}

export default Contacto