import React from 'react'
//Se importan las librerías de React
const Nosotros = () => {

    return (

        <div>

            <h1> Nosotros </h1>

        </div>

    )

}

export default Nosotros