const style = {

    input: {

        Color:'white',
        fontSize: '4rem',
        
        
    },

}