import React from 'react'
//Se importan las librerías de React
const Inicio = () => {

    return (

        <div>

            <h1> Inicio </h1>

        </div>

    )

}

export default Inicio