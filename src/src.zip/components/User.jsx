import React from "react";

function User ( { username } ) {

    return (

    <div>

        <h1> User: { username } </h1>

        {/*

            Se envían los cambios a la variable

         */}

    </div>

    );

}

export default User;